package com.koreait.service;

import com.koreait.vo.CardVO;

public interface TransactionService {

	public void execute(CardVO cardVO);
	
}
